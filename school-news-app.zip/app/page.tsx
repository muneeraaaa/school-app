import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, User, MapPin } from "lucide-react"

export default function SchoolNewsPage() {
  const currentDate = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const featuredNews = [
    {
      id: 1,
      headline: "Lincoln High Wins State Championship in Robotics",
      byline: "By Sarah Johnson, Student Reporter",
      category: "ACADEMICS",
      summary:
        "Our robotics team brought home the gold after months of preparation and innovation. The team's autonomous robot impressed judges with its precision and creativity in solving complex challenges.",
      time: "2 hours ago",
      featured: true,
    },
    {
      id: 2,
      headline: "New Library Wing Opens Next Month",
      byline: "By Principal Martinez",
      category: "FACILITIES",
      summary:
        "The long-awaited expansion will feature modern study spaces, a maker lab, and over 10,000 new books. Students can expect state-of-the-art technology and collaborative learning areas.",
      time: "5 hours ago",
      featured: false,
    },
    {
      id: 3,
      headline: "Drama Club Presents 'Romeo and Juliet'",
      byline: "By Ms. Thompson, Drama Teacher",
      category: "ARTS",
      summary:
        "Join us for three nights of Shakespeare's timeless tragedy. Our talented students have been rehearsing since September for this spectacular production.",
      time: "1 day ago",
      featured: false,
    },
  ]

  const sidebarNews = [
    {
      title: "Winter Dance Tickets on Sale",
      time: "3 hours ago",
      category: "EVENTS",
    },
    {
      title: "Flu Shot Clinic This Friday",
      time: "6 hours ago",
      category: "HEALTH",
    },
    {
      title: "College Fair Next Tuesday",
      time: "1 day ago",
      category: "ACADEMICS",
    },
    {
      title: "Basketball Team Advances to Finals",
      time: "2 days ago",
      category: "SPORTS",
    },
  ]

  const upcomingEvents = [
    {
      title: "Parent-Teacher Conferences",
      date: "Dec 15-16",
      location: "Main Building",
    },
    {
      title: "Winter Break Begins",
      date: "Dec 20",
      location: "All Campus",
    },
    {
      title: "Science Fair",
      date: "Jan 12",
      location: "Gymnasium",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b-4 border-primary bg-background">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xl">LH</span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Est. 1952</p>
                <p className="text-sm text-muted-foreground">{currentDate}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Volume 72, Issue 45</p>
              <p className="text-sm text-muted-foreground">Lincoln High School</p>
            </div>
          </div>

          <div className="text-center">
            <h1 className="text-6xl font-black text-primary mb-2" style={{ fontFamily: "var(--font-merriweather)" }}>
              THE LINCOLN HERALD
            </h1>
            <p className="text-lg text-muted-foreground italic">Your Daily Source for School News</p>
          </div>

          <nav className="mt-6 border-t border-b border-border py-2">
            <div className="flex justify-center gap-8">
              {["NEWS", "SPORTS", "ACADEMICS", "ARTS", "EVENTS"].map((section) => (
                <Button key={section} variant="ghost" className="font-semibold text-sm">
                  {section}
                </Button>
              ))}
            </div>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main News Column */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Featured Article */}
              <Card className="md:col-span-2 border-2 border-primary">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary" className="bg-primary text-primary-foreground">
                      {featuredNews[0].category}
                    </Badge>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {featuredNews[0].time}
                    </div>
                  </div>
                  <CardTitle
                    className="text-3xl font-black leading-tight text-balance"
                    style={{ fontFamily: "var(--font-merriweather)" }}
                  >
                    {featuredNews[0].headline}
                  </CardTitle>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <User className="w-4 h-4" />
                    {featuredNews[0].byline}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-lg leading-relaxed text-pretty mb-4">{featuredNews[0].summary}</p>
                  <Button
                    variant="outline"
                    className="text-accent hover:bg-accent hover:text-accent-foreground bg-transparent"
                  >
                    Read Full Story
                  </Button>
                </CardContent>
              </Card>

              {/* Secondary Articles */}
              {featuredNews.slice(1).map((article) => (
                <Card key={article.id} className="border border-border">
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="text-xs">
                        {article.category}
                      </Badge>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        {article.time}
                      </div>
                    </div>
                    <CardTitle
                      className="text-xl font-bold leading-tight text-balance"
                      style={{ fontFamily: "var(--font-merriweather)" }}
                    >
                      {article.headline}
                    </CardTitle>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <User className="w-3 h-3" />
                      {article.byline}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed text-pretty mb-3">{article.summary}</p>
                    <Button variant="ghost" size="sm" className="text-accent hover:bg-accent/10 p-0 h-auto">
                      Continue reading →
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Breaking News */}
            <Card className="bg-sidebar border-sidebar-border">
              <CardHeader>
                <CardTitle
                  className="text-lg font-bold text-sidebar-foreground"
                  style={{ fontFamily: "var(--font-merriweather)" }}
                >
                  Latest Updates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {sidebarNews.map((item, index) => (
                  <div key={index} className="border-b border-sidebar-border last:border-b-0 pb-3 last:pb-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-xs">
                        {item.category}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{item.time}</span>
                    </div>
                    <h4 className="font-semibold text-sm leading-tight text-sidebar-foreground">{item.title}</h4>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Upcoming Events */}
            <Card className="bg-sidebar border-sidebar-border">
              <CardHeader>
                <CardTitle
                  className="text-lg font-bold text-sidebar-foreground"
                  style={{ fontFamily: "var(--font-merriweather)" }}
                >
                  Upcoming Events
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {upcomingEvents.map((event, index) => (
                  <div key={index} className="border-b border-sidebar-border last:border-b-0 pb-3 last:pb-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Calendar className="w-4 h-4 text-sidebar-primary" />
                      <span className="font-semibold text-sm text-sidebar-primary">{event.date}</span>
                    </div>
                    <h4 className="font-semibold text-sm text-sidebar-foreground mb-1">{event.title}</h4>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">{event.location}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Weather Widget */}
            <Card className="bg-sidebar border-sidebar-border">
              <CardHeader>
                <CardTitle
                  className="text-lg font-bold text-sidebar-foreground"
                  style={{ fontFamily: "var(--font-merriweather)" }}
                >
                  Today's Weather
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-sidebar-foreground mb-2">72°F</div>
                  <p className="text-sm text-muted-foreground">Partly Cloudy</p>
                  <p className="text-xs text-muted-foreground mt-2">Perfect weather for outdoor activities!</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-bold mb-4" style={{ fontFamily: "var(--font-merriweather)" }}>
                Contact Us
              </h3>
              <p className="text-sm">Lincoln High School</p>
              <p className="text-sm">123 Education Blvd</p>
              <p className="text-sm">Springfield, ST 12345</p>
              <p className="text-sm mt-2">(555) 123-4567</p>
            </div>
            <div>
              <h3 className="font-bold mb-4" style={{ fontFamily: "var(--font-merriweather)" }}>
                Quick Links
              </h3>
              <ul className="text-sm space-y-1">
                <li>
                  <a href="#" className="hover:text-accent">
                    Student Portal
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent">
                    Parent Resources
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent">
                    Staff Directory
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent">
                    Calendar
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-4" style={{ fontFamily: "var(--font-merriweather)" }}>
                Follow Us
              </h3>
              <div className="flex gap-4">
                <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-accent">
                  Facebook
                </Button>
                <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-accent">
                  Twitter
                </Button>
                <Button variant="ghost" size="sm" className="text-primary-foreground hover:text-accent">
                  Instagram
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-primary-foreground/20 mt-8 pt-4 text-center">
            <p className="text-sm">&copy; 2024 Lincoln High School. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
